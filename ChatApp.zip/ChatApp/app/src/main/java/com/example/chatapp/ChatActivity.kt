package com.example.chatapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.URI

class ChatActivity : AppCompatActivity() {

    private var currentUserId = -1
    private var receiverId = -1
    private lateinit var messageAdapter: MessageAdapter
    private val messageList = mutableListOf<Message>()
    private var webSocketClient: WebSocketClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        currentUserId = intent.getIntExtra("currentUserId", -1)
        receiverId = intent.getIntExtra("receiverId", -1)
        val receiverName = intent.getStringExtra("receiverName") ?: "Chat"
        title = receiverName

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerMessages)
        val etMessage = findViewById<EditText>(R.id.etMessage)
        val btnSend = findViewById<Button>(R.id.btnSend)

        messageAdapter = MessageAdapter(messageList, currentUserId)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = messageAdapter

        loadMessageHistory()
        connectWebSocket()

        btnSend.setOnClickListener {
            val text = etMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                sendMessage(text)
                etMessage.setText("")
            }
        }
    }

    private fun loadMessageHistory() {
        RetrofitClient.instance.getMessageHistory(currentUserId, receiverId)
            .enqueue(object : Callback<MessageHistoryResponse> {
                override fun onResponse(call: Call<MessageHistoryResponse>, response: Response<MessageHistoryResponse>) {
                    if (response.isSuccessful && response.body()?.status == "success") {
                        val messages = response.body()?.messages ?: emptyList()
                        messages.forEach { it.isSentByMe = it.sender_id == currentUserId }
                        messageList.addAll(messages)
                        messageAdapter.notifyDataSetChanged()
                        findViewById<RecyclerView>(R.id.recyclerMessages)
                            .scrollToPosition(messageAdapter.itemCount - 1)
                    }
                }
                override fun onFailure(call: Call<MessageHistoryResponse>, t: Throwable) {
                    Toast.makeText(this@ChatActivity, "Network error", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun connectWebSocket() {
        val uri = URI("ws://192.168.11.108:3000")
        webSocketClient = object : WebSocketClient(uri) {
            override fun onOpen(handshakedata: ServerHandshake?) {}
            override fun onMessage(message: String?) {
                message?.let {
                    val parts = it.split("|")
                    if (parts.size == 3) {
                        val senderId = parts[0].toIntOrNull() ?: return
                        val receiverIdMsg = parts[1].toIntOrNull() ?: return
                        val text = parts[2]
                        if ((senderId == currentUserId && receiverIdMsg == receiverId) ||
                            (senderId == receiverId && receiverIdMsg == currentUserId)) {
                            val msg = Message(0, senderId, receiverIdMsg, text, "", senderId == currentUserId)
                            runOnUiThread {
                                messageList.add(msg)
                                messageAdapter.notifyItemInserted(messageList.size - 1)
                                findViewById<RecyclerView>(R.id.recyclerMessages)
                                    .scrollToPosition(messageList.size - 1)
                            }
                        }
                    }
                }
            }
            override fun onClose(code: Int, reason: String?, remote: Boolean) {}
            override fun onError(ex: Exception?) {}
        }
        webSocketClient?.connect()
    }

    private fun sendMessage(text: String) {
        val body = mapOf(
            "sender_id" to currentUserId.toString(),
            "receiver_id" to receiverId.toString(),
            "message" to text
        )
        RetrofitClient.instance.saveMessage(body)
            .enqueue(object : Callback<GenericResponse> {
                override fun onResponse(call: Call<GenericResponse>, response: Response<GenericResponse>) {}
                override fun onFailure(call: Call<GenericResponse>, t: Throwable) {}
            })
        webSocketClient?.send("$currentUserId|$receiverId|$text")
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocketClient?.close()
    }
}

class MessageAdapter(
    private val messages: MutableList<Message>,
    private val currentUserId: Int
) : RecyclerView.Adapter<MessageAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvMessage: TextView = view.findViewById(R.id.tvMessage)
        val tvTime: TextView = view.findViewById(R.id.tvTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layout = if (viewType == 1) R.layout.item_message_sent else R.layout.item_message_received
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemViewType(position: Int) = if (messages[position].isSentByMe) 1 else 0

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvMessage.text = messages[position].message
        holder.tvTime.text = messages[position].timestamp
    }

    override fun getItemCount() = messages.size
}