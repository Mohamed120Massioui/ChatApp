package com.example.chatapp

import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @POST("register")
    fun register(@Body request: RegisterRequest): Call<String>

    @POST("login")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @GET("contacts")
    fun getContacts(): Call<ContactsResponse>

    @GET("messages/{senderId}/{receiverId}")
    fun getMessageHistory(
        @Path("senderId") senderId: Int,
        @Path("receiverId") receiverId: Int
    ): Call<MessageHistoryResponse>

    @POST("saveMessage")
    fun saveMessage(@Body requestBody: Map<String, String>): Call<GenericResponse>
}
