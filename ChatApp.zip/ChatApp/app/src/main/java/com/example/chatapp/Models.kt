package com.example.chatapp

data class RegisterRequest(val username: String, val password: String)
data class LoginRequest(val username: String, val password: String)
data class LoginResponse(val status: String, val userId: Int)

data class Contact(val id: Int, val username: String)
data class ContactsResponse(val status: String, val contacts: List<Contact>)

data class Message(
    val id: Int,
    val sender_id: Int,
    val receiver_id: Int,
    val message: String,
    val timestamp: String,
    var isSentByMe: Boolean = false
)
data class MessageHistoryResponse(val status: String, val messages: List<Message>)
data class GenericResponse(val status: String)