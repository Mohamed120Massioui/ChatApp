package com.example.chatapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ContactsActivity : AppCompatActivity() {

    private var currentUserId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contacts)

        currentUserId = intent.getIntExtra("userId", -1)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerContacts)
        recyclerView.layoutManager = LinearLayoutManager(this)

        RetrofitClient.instance.getContacts()
            .enqueue(object : Callback<ContactsResponse> {
                override fun onResponse(call: Call<ContactsResponse>, response: Response<ContactsResponse>) {
                    if (response.isSuccessful && response.body()?.status == "success") {
                        val contacts = response.body()?.contacts ?: listOf()
                        recyclerView.adapter = ContactsAdapter(contacts) { contact ->
                            val intent = Intent(this@ContactsActivity, ChatActivity::class.java)
                            intent.putExtra("currentUserId", currentUserId)
                            intent.putExtra("receiverId", contact.id)
                            intent.putExtra("receiverName", contact.username)
                            startActivity(intent)
                        }
                    } else {
                        Toast.makeText(this@ContactsActivity, "Failed to load contacts", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ContactsResponse>, t: Throwable) {
                    Toast.makeText(this@ContactsActivity, "Network error", Toast.LENGTH_SHORT).show()
                }
            })
    }
}

class ContactsAdapter(
    private val contacts: List<Contact>,
    private val onClick: (Contact) -> Unit
) : RecyclerView.Adapter<ContactsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvContactName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contact = contacts[position]
        holder.tvName.text = contact.username
        holder.itemView.setOnClickListener { onClick(contact) }
    }

    override fun getItemCount() = contacts.size
}